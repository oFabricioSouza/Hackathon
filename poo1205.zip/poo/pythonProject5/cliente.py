class Cliente:
    def __init__(self, nome, sobrenome, cpf):
        self.nome = nome
        self.sobrenome = sobrenome
        self.cpf = cpf

    def exibir(self):
        print(f'Nome: {self.nome}\n'
              f'Sobrenome: {self.sobrenome}\n'
              f'CPF: {self.cpf}')
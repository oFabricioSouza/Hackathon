from conta import *
from cliente import *

if __name__ == '__main__':
    cliente1 = Cliente('Lucas', 'Cerqueira', '146.349.257-02')
    conta1 = Conta('1234-5', cliente1, 1000, 5000)
    conta1.extrato()

    #cliente1.exibir()
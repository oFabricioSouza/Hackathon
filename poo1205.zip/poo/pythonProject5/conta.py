from cliente import Cliente
from historico import Historico

class Conta:
    def __init__(self, numero, cliente, saldo, limite):
        self.numero = numero
        self.titular = cliente
        self.saldo = saldo
        self.limite = limite
        self.historico = Historico()
        

    def deposita(self,valor):
        self.saldo += valor
        self.historico.transacoes.append('Depósito de R${}'.format(valor))

    def saca(self,valor):
        if (self.saldo >= valor):
            self.saldo -= valor
            print(f'O seu novo saldo é: {self.saldo}')
            self.historico.transacoes.append('Saque de R${}'.format(valor))
        else:
            print('Procura um agiota')

    def transfere_para(self,destino,valor):
        self.saldo -= valor
        destino.saldo += valor
        self.historico.transacoes.append('Transferência de R${} para {}.'.format(valor, destino))

    def extrato(self):
        print(f'O número da conta é: {self.numero} \n'
              f'O nome do titular é: {self.titular} \n'
              f'O saldo da conta é: {self.saldo}')